#!/bin/python3
import GUI_Balanza

if __name__ == "__main__":
    GUI_Balanza.setUpGUI()
